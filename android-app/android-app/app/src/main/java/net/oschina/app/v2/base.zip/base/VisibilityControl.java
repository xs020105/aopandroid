package net.oschina.app.v2.base;
/*
* 注者 仝秦玮
*
* 2016.12.27
*
* 定义接口
*
* 实现可视化
*
* */
public interface VisibilityControl {

	public abstract boolean isVisible();
}
