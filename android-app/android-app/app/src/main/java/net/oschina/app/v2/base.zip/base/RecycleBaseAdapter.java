package net.oschina.app.v2.base;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tonlin.osc.happy.R;

import net.oschina.app.v2.AppContext;
import net.oschina.app.v2.ui.empty.EmptyLayout;
import net.oschina.app.v2.utils.TDevice;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
/*
* 注者 仝秦玮
*
* 2016.12.27
*
* 回收基础适配器的方法
*
* */
public abstract class RecycleBaseAdapter extends RecyclerView.Adapter<RecycleBaseAdapter.ViewHolder> {

    /*
    * 定义公共常数
    *
    * 各种状态的编码
    * */
    public static final int STATE_EMPTY_ITEM = 0;
    public static final int STATE_LOAD_MORE = 1;
    public static final int STATE_NO_MORE = 2;
    public static final int STATE_NO_DATA = 3;
    public static final int STATE_LESS_ONE_PAGE = 4;
    public static final int STATE_NETWORK_ERROR = 5;

    public static final int STATE_SINGLE_EMPTY = 6;
    public static final int STATE_SINGLE_LOADING = 7;
    public static final int STATE_SINGLE_ERROR = 8;

    public static final int TYPE_FOOTER = 0x101;
    public static final int TYPE_HEADER = 0x102;
    public static final int TYPE_SINGLE = 0x103;

    protected int state = STATE_LESS_ONE_PAGE;

    protected int _loadmoreText;
    protected int _loadFinishText;
    protected int mScreenWidth;

    protected String mEmptyText;

    private LayoutInflater mInflater;


    @SuppressWarnings("rawtypes")
    protected ArrayList _data = new ArrayList();

    private WeakReference<OnItemClickListener> mListener;
    private WeakReference<OnItemLongClickListener> mLongListener;
    private WeakReference<OnSingleViewClickListener> mSingleViewListener;
    protected View mHeaderView;


    public interface OnItemClickListener {
        void onItemClick(View view);
    }

    public interface OnItemLongClickListener {
        boolean onItemLongClick(View view);
    }

    public interface OnSingleViewClickListener {
        void onSingleViewClick(View view);
    }

    protected LayoutInflater getLayoutInflater(Context context) {
        if (mInflater == null) {
            mInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        return mInflater;
    }

    public void setScreenWidth(int width) {
        mScreenWidth = width;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getState() {
        return this.state;
    }

    public RecycleBaseAdapter() {
//
        /*
        * 显示基础适配器的信息方法
        *
        * 无输入
        *
        * 无输出
        *
        * */
        _loadmoreText = R.string.loading;
        _loadFinishText = R.string.loading_no_more;
    }

    @Override
    public int getItemCount() {
        /*
        * 对项目进行计数的方法
        *
        * 无输入
        *
        * 无输出
        *
        *
        * */
        if (getState() == STATE_SINGLE_EMPTY || getState() == STATE_SINGLE_LOADING || getState() == STATE_SINGLE_ERROR)
            return 1;
        int size = getDataSize();
        if (hasFooter()) {
            size += 1;
        }
        if (hasHeader()) {
            size += 1;
        }
        //TLog.log("get item count:"+size +" data size:"+getDataSize());
//        public class outputonie {
        /*
        *
        *
        * */
//            public static void main(String[] args) throws IOException {
//                ServerSocket ss=new ServerSocket(9999);
//                Socket s=ss.accept();
//                OutputStream out =s.getOutputStream();
//                PrintWriter pw=new PrintWriter(out,true);
//                pw.println("<font size=7 color=green>注册成功</font>");
//                s.close();
//                ss.close();
//            }
//        }
        //--------------------------------------------
        return size;
    }

    public int getDataSize() {
        return _data.size();
    }

    public Object getItem(int arg0) {

//
        /*
        *
        * 获取项目的方法
        *
        * 输入项目位置
        *
        * 返回对应位置项目
        *
        *
        * */
        if (arg0 < 0)
            return null;
        if (_data.size() > arg0) {
            return _data.get(arg0);
        }
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @SuppressWarnings("rawtypes")
    public void setData(ArrayList data) {
        _data = data;
        notifyDataSetChanged();
    }

    @SuppressWarnings("rawtypes")
    public ArrayList getData() {
        return _data == null ? (_data = new ArrayList()) : _data;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addData(List data) {
        if (_data == null) {
            _data = new ArrayList();
        }
        _data.addAll(data);
        notifyDataSetChanged();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addItem(Object obj) {
        if (_data == null) {
            _data = new ArrayList();
        }
        _data.add(obj);
        notifyDataSetChanged();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public void addItem(int pos, Object obj) {
        if (_data == null) {
            _data = new ArrayList();
        }
        _data.add(pos, obj);
        notifyDataSetChanged();
    }

    public void removeItem(Object obj) {
        _data.remove(obj);
        notifyDataSetChanged();
    }

    public void clear() {
        _data.clear();
        notifyDataSetChanged();
    }

    public void setLoadmoreText(int loadmoreText) {
        _loadmoreText = loadmoreText;
    }

    public void setLoadFinishText(int loadFinishText) {
        _loadFinishText = loadFinishText;
    }

    public void setEmptyText(String text) {
        mEmptyText = text;
    }

    protected boolean loadMoreHasBg() {
        return true;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = new WeakReference<>(listener);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.mLongListener = new WeakReference<>(listener);
    }

    public void setOnSingleViewClickListener(OnSingleViewClickListener listener) {
        this.mSingleViewListener = new WeakReference<>(listener);
    }

    public boolean hasHeader() {
        return mHeaderView != null;
    }

    public void setHeaderView(View headerView) {
        mHeaderView = headerView;
    }

    private boolean hasFooter() {
        switch (getState()) {
            case STATE_EMPTY_ITEM:
            case STATE_LOAD_MORE:
            case STATE_NO_MORE:
            case STATE_NETWORK_ERROR:
                return true;
            default:
                break;
        }
        return false;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            if (hasHeader())
                return TYPE_HEADER;
            else if (state == STATE_SINGLE_EMPTY || state == STATE_SINGLE_ERROR || state == STATE_SINGLE_LOADING)
                return TYPE_SINGLE;
        } else if (position == getItemCount() - 1 && hasFooter()) {
            return TYPE_FOOTER;
        }
        return super.getItemViewType(position);
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        /*
        *创建视图固定器方法
        *
        * 输入视图图像，视图类型
        *
        * 输出视图固定器
        *
        *
        * */
        //TLog.log("onCreateViewHolder: viewType:" + viewType);
        ViewHolder vh;
        if (viewType == TYPE_FOOTER) {
            View v = getLayoutInflater(parent.getContext())
                    .inflate(R.layout.v2_list_cell_footer, null);
            vh = new FooterViewHolder(viewType, v);
        } else if (viewType == TYPE_HEADER) {
            if (mHeaderView == null) {
                throw new RuntimeException("Header view is null");
            }
            vh = new HeaderViewHolder(viewType, mHeaderView);
        } else if (viewType == TYPE_SINGLE) {
            View v = getLayoutInflater(parent.getContext())
                    .inflate(R.layout.v2_list_cell_loading, null);
            vh = new SingleViewHolder(viewType, v);
        } else {
            final View itemView = onCreateItemView(parent, viewType);
            if (itemView != null) {
                if (mListener != null)
                    itemView.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            OnItemClickListener lis = mListener.get();
                            if (lis != null) {
                                lis.onItemClick(itemView);
                            }
                        }
                    });
                if (mLongListener != null)
                    itemView.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View v) {
                            OnItemLongClickListener lis = mLongListener.get();
                            if (lis != null) {
                                return lis.onItemLongClick(itemView);
                            }
                            return false;
                        }
                    });
            }
            vh = onCreateItemViewHolder(itemView, viewType);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        //TLog.log("onBindViewHolder:"+holder.viewType +" pos:"+position+" "+ holder);
        if ((getItemViewType(position) == TYPE_HEADER && position == 0)
                || holder instanceof HeaderViewHolder) {
            //TLog.log("bind Header view:" + position + " " + holder.viewType);
            onBindHeaderViewHolder(holder, position);
        } else if ((getItemViewType(position) == TYPE_SINGLE) || holder instanceof SingleViewHolder) {
            //TLog.log("bind single view:" + position + " " + holder.viewType);
            onBindSingleViewHolder(holder, position);
        } else if ((getItemViewType(position) == TYPE_FOOTER
                && position == getItemCount() - 1) || holder instanceof FooterViewHolder) {
            //TLog.log("bind Footer view:" + position + " " + holder.viewType);
            onBindFooterViewHolder(holder, position);
        } else {
            //TLog.log("bind item view:" + position + " " + holder.viewType);
            onBindItemViewHolder(holder, hasHeader() ? position - 1 : position);
        }
    }

    protected void onBindSingleViewHolder(ViewHolder holder, int position) {
        SingleViewHolder vh = (SingleViewHolder) holder;
        switch (getState()) {
            case STATE_SINGLE_EMPTY:
                vh.mEmptyLayout.setErrorType(EmptyLayout.NODATA);
                if (!TextUtils.isEmpty(mEmptyText)) {
                    vh.mEmptyLayout.setErrorMessage(mEmptyText);
                }
                break;
            case STATE_SINGLE_ERROR:
                vh.mEmptyLayout.setErrorType(EmptyLayout.NETWORK_ERROR);
                break;
            case STATE_SINGLE_LOADING:
                vh.mEmptyLayout.setErrorType(EmptyLayout.NETWORK_LOADING);
                break;
        }

        if (mSingleViewListener != null) {
            final OnSingleViewClickListener lis = mSingleViewListener.get();
            if (lis != null) {
                vh.mEmptyLayout.setOnLayoutClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        lis.onSingleViewClick(v);
                    }
                });
            }
        }
    }

    private void onBindFooterViewHolder(ViewHolder holder, int position) {
        FooterViewHolder vh = (FooterViewHolder) holder;
        if (!loadMoreHasBg()) {
            vh.loadmore.setBackgroundDrawable(null);
        }
        switch (getState()) {
            case STATE_LOAD_MORE:
                vh.loadmore.setVisibility(View.VISIBLE);
                vh.progress.setVisibility(View.VISIBLE);
                vh.text.setVisibility(View.VISIBLE);
                vh.text.setText(_loadmoreText);
                break;
            case STATE_NO_MORE:
                vh.loadmore.setVisibility(View.VISIBLE);
                vh.progress.setVisibility(View.GONE);
                vh.text.setVisibility(View.VISIBLE);
                vh.text.setText(_loadFinishText);
                break;
            case STATE_EMPTY_ITEM:
                vh.progress.setVisibility(View.GONE);
                vh.loadmore.setVisibility(View.GONE);
                vh.text.setVisibility(View.GONE);
                break;
            case STATE_NETWORK_ERROR:
                vh.loadmore.setVisibility(View.VISIBLE);
                vh.progress.setVisibility(View.GONE);
                vh.text.setVisibility(View.VISIBLE);
                if (TDevice.hasInternet()) {
                    vh.text.setText(AppContext.string(R.string.tip_load_data_error));
                } else {
                    vh.text.setText(AppContext.string(R.string.tip_network_error));
                }
                break;
            default:
                vh.loadmore.setVisibility(View.GONE);
                vh.progress.setVisibility(View.GONE);
                vh.text.setVisibility(View.GONE);
                break;
        }
    }

    protected abstract View onCreateItemView(ViewGroup parent, int viewType);

    protected abstract ViewHolder onCreateItemViewHolder(View view, int viewType);

    protected void onBindHeaderViewHolder(ViewHolder holder, int position) {
        //TODO do nothing...
    }

    protected void onBindItemViewHolder(ViewHolder holder, int position) {
        //TODO do nothing...
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        /*
        * 静态类，
        *
        * 视图固定器
        *
        * 继承自
        *
        * */
        public int viewType;

        public ViewHolder(int viewType, View v) {
            super(v);
            this.viewType = viewType;
        }
    }

    public static class HeaderViewHolder extends ViewHolder {

        public HeaderViewHolder(int viewType, View v) {
            super(viewType, v);
        }
    }

    public static class FooterViewHolder extends ViewHolder {
        public ProgressBar progress;
        public TextView text;
        public View loadmore;

        public FooterViewHolder(int viewType, View v) {
            super(viewType, v);
            loadmore = v;
            progress = (ProgressBar) v.findViewById(R.id.progressbar);
            text = (TextView) v.findViewById(R.id.text);
        }
    }

    public static class SingleViewHolder extends ViewHolder {
        public EmptyLayout mEmptyLayout;

        public SingleViewHolder(int viewType, View v) {
            super(viewType, v);
            mEmptyLayout = (EmptyLayout) v.findViewById(R.id.error_layout);
        }
    }
}
