package net.oschina.app.v2.base;
/*
* 注者 仝秦玮
*
* 2017.1.11
*
* 这纯属是为了完成任务
*
* 这个类也太少了吧
*
* 连构造函数都没有
*
* 这么过分
*
*基础碎片制表类
*
* 继承自基础碎片类
*
*
* */
public class BaseTabFragment extends BaseFragment {


}
